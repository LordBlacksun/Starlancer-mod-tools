// SLExtractorDlg.h : header file
//

#if !defined(AFX_SLEXTRACTORDLG_H__3D6983EE_0AA4_41E6_9143_4E052B23B3F1__INCLUDED_)
#define AFX_SLEXTRACTORDLG_H__3D6983EE_0AA4_41E6_9143_4E052B23B3F1__INCLUDED_

#include "bigf.h"	// Added by ClassView
#include "MMFILE.H"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSLExtractorDlg dialog

class CSLExtractorDlg : public CDialog
{
// Construction
public:
	CSLExtractorDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSLExtractorDlg)
	enum { IDD = IDD_SLEXTRACTOR_DIALOG };
	CButton	m_Close;
	CButton	m_Extract;
	CButton	m_SelectNone;
	CButton	m_SelectAll;
	CListCtrl	m_FileList;
	CString	m_Filename;
	CString	m_Display;
	CString	m_OutputDir;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSLExtractorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	char * m_fileptr;
	CMemoryMappedFile m_SharedFile;
	CFile m_file;
	int m_FileIsValid;
	THeader m_header;
	HICON m_hIcon;

	TFileEntry *m_entries;

	// Generated message map functions
	//{{AFX_MSG(CSLExtractorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelectNone();
	afx_msg void OnBrowse();
	afx_msg void OnSelectAll();
	afx_msg void OnFileOpen();
	afx_msg void OnFileClose();
	afx_msg void OnClose();
	afx_msg void OnChangeFile();
	afx_msg void OnExtract();
	afx_msg void OnBrowseOutput();
	afx_msg void OnChangeOutputDir();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SLEXTRACTORDLG_H__3D6983EE_0AA4_41E6_9143_4E052B23B3F1__INCLUDED_)
