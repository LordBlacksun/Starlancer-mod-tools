// bigf.cpp:
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "bigf.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

int
le (char *a)
{
    unsigned char *s = (unsigned char *) a;
    return (int) (s[0] << 24 | s[1] << 16 | s[2] << 8 | s[3]);
};
