// SLExtractorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SLExtractor.h"
#include "SLExtractorDlg.h"
#include "bigf.h"
#include "mmfile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg:public CDialog
{
  public:
    CAboutDlg ();

// *INDENT-OFF*

    // Dialog Data
    //{{AFX_DATA(CAboutDlg)
    enum { IDD = IDD_ABOUTBOX };
    CString m_DisplayAbout;
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAboutDlg)
    protected:
    virtual void DoDataExchange (CDataExchange * pDX);	// DDX/DDV support
    //}}AFX_VIRTUAL

    // Implementation
    protected:
    //{{AFX_MSG(CAboutDlg)
    virtual BOOL OnInitDialog ();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP ()

// *INDENT-ON*
};

CAboutDlg::CAboutDlg ():CDialog (CAboutDlg::IDD)
{
    //{{AFX_DATA_INIT(CAboutDlg)
    m_DisplayAbout = _T ("");
    //}}AFX_DATA_INIT
}

void
CAboutDlg::DoDataExchange (CDataExchange * pDX)
{
    CDialog::DoDataExchange (pDX);
    //{{AFX_DATA_MAP(CAboutDlg)
    DDX_Text (pDX, IDC_DISPLAYABOUT, m_DisplayAbout);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP (CAboutDlg, CDialog)
    //{{AFX_MSG_MAP(CAboutDlg)
    //}}AFX_MSG_MAP
    END_MESSAGE_MAP ()
/////////////////////////////////////////////////////////////////////////////
// CSLExtractorDlg dialog
    CSLExtractorDlg::CSLExtractorDlg (CWnd * pParent /*=NULL*/ )
:  CDialog (CSLExtractorDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CSLExtractorDlg)
    m_Filename = _T ("");
    m_Display = _T ("");
    m_OutputDir = _T ("");
    //}}AFX_DATA_INIT
    // Note that LoadIcon does not require a subsequent DestroyIcon in Win32
    m_hIcon = AfxGetApp ()->LoadIcon (IDR_MAINFRAME);
}

void
CSLExtractorDlg::DoDataExchange (CDataExchange * pDX)
{
    CDialog::DoDataExchange (pDX);

// *INDENT-OFF*
    //{{AFX_DATA_MAP(CSLExtractorDlg)
    DDX_Control (pDX, IDC_CLOSE, m_Close);
    DDX_Control (pDX, IDC_EXTRACT, m_Extract);
    DDX_Control (pDX, IDC_SELECTNONE, m_SelectNone);
    DDX_Control (pDX, IDC_SELECTALL, m_SelectAll);
    DDX_Control (pDX, IDC_FILELIST, m_FileList);
    DDX_Text (pDX, IDC_FILE, m_Filename);
    DDX_Text (pDX, IDC_DISPLAY, m_Display);
    DDX_Text (pDX, IDC_OUTPUTDIR, m_OutputDir);
    //}}AFX_DATA_MAP
// *INDENT-ON*
}

// *INDENT-OFF*

BEGIN_MESSAGE_MAP (CSLExtractorDlg, CDialog)
    //{{AFX_MSG_MAP(CSLExtractorDlg)
    ON_WM_SYSCOMMAND ()
    ON_WM_PAINT ()
    ON_WM_QUERYDRAGICON ()
    ON_BN_CLICKED(IDC_SELECTNONE, OnSelectNone) 
    ON_BN_CLICKED (IDC_BROWSE, OnBrowse)
    ON_BN_CLICKED (IDC_SELECTALL, OnSelectAll) 
    ON_BN_CLICKED (IDC_OPEN, OnFileOpen)
    ON_BN_CLICKED (IDC_CLOSE, OnFileClose) 
    ON_WM_CLOSE ()
    ON_EN_CHANGE (IDC_FILE, OnChangeFile)
    ON_BN_CLICKED (IDC_EXTRACT, OnExtract) 
    ON_BN_CLICKED (IDC_BROWSEOUTPUT, OnBrowseOutput)
    ON_EN_CHANGE (IDC_OUTPUTDIR, OnChangeOutputDir) 
    ON_BN_CLICKED (IDC_ABOUT, OnAbout)
    //}}AFX_MSG_MAP
    END_MESSAGE_MAP ()
// *INDENT-ON*
/////////////////////////////////////////////////////////////////////////////
// CSLExtractorDlg message handlers
     BOOL CSLExtractorDlg::OnInitDialog ()
{
    CDialog::OnInitDialog ();

    // Add "About..." menu item to system menu.

    // IDM_ABOUTBOX must be in the system command range.
    ASSERT ((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT (IDM_ABOUTBOX < 0xF000);

    CMenu *pSysMenu = GetSystemMenu (FALSE);
    if (pSysMenu != NULL)
      {
	  CString strAboutMenu;
	  strAboutMenu.LoadString (IDS_ABOUTBOX);
	  if (!strAboutMenu.IsEmpty ())
	    {
		pSysMenu->AppendMenu (MF_SEPARATOR);
		pSysMenu->AppendMenu (MF_STRING, IDM_ABOUTBOX, strAboutMenu);
	    }
      }

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon (m_hIcon, TRUE);	// Set big icon
    SetIcon (m_hIcon, FALSE);	// Set small icon

    m_FileList.InsertColumn (0, "Name", LVCFMT_LEFT, 200);
    m_FileList.InsertColumn (1, "Size", LVCFMT_RIGHT, 70);

    // TODO: Add extra initialization here
    m_FileIsValid = FALSE;

    // force UI update
    OnFileClose ();


    return TRUE;		// return TRUE  unless you set the focus to a control
}

void
CSLExtractorDlg::OnSysCommand (UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
      {
	  CAboutDlg dlgAbout;
	  dlgAbout.DoModal ();
      }
    else
      {
	  CDialog::OnSysCommand (nID, lParam);
      }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void
CSLExtractorDlg::OnPaint ()
{
    if (IsIconic ())
      {
	  CPaintDC dc (this);	// device context for painting

	  SendMessage (WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc (), 0);

	  // Center icon in client rectangle
	  int cxIcon = GetSystemMetrics (SM_CXICON);
	  int cyIcon = GetSystemMetrics (SM_CYICON);
	  CRect rect;
	  GetClientRect (&rect);
	  int x = (rect.Width () - cxIcon + 1) / 2;
	  int y = (rect.Height () - cyIcon + 1) / 2;

	  // Draw the icon
	  dc.DrawIcon (x, y, m_hIcon);
      }
    else
      {
	  CDialog::OnPaint ();
      }
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR
CSLExtractorDlg::OnQueryDragIcon ()
{
    return (HCURSOR) m_hIcon;
}

void
CSLExtractorDlg::OnSelectNone ()
{
    ASSERT (m_FileIsValid);

    m_FileList.SetFocus ();

    for (int i = 0; i < m_header.num_files; i++)
	m_FileList.SetItemState (i, 0, LVIS_SELECTED);

}

void
CSLExtractorDlg::OnBrowse ()
{
    char szFilter[] =
	"Star Lancer HOG Files (*.hog)|*.hog|All Files (*.*)|*.*||";

    CFileDialog opendlg (TRUE, "hog", NULL,
			 OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilter);
    if (opendlg.DoModal () == IDOK)
      {
	  m_Filename = opendlg.GetFileName ();
	  OnFileClose ();
      }
}

void
CSLExtractorDlg::OnSelectAll ()
{
    ASSERT (m_FileIsValid);

    m_FileList.SetFocus ();

    for (int i = 0; i < m_header.num_files; i++)
	m_FileList.SetItemState (i, LVIS_SELECTED, LVIS_SELECTED);

}

void
CSLExtractorDlg::OnFileOpen ()
{
    OnFileClose ();

    if (m_file.Open (m_Filename, CFile::modeRead | CFile::shareDenyWrite) ==
	0)
      {
	  m_Display = "Can't open file.";
	  UpdateData (FALSE);
	  return;
      }

    WIN32_FIND_DATA FindFileData;
    FindFirstFile (m_Filename, &FindFileData);

    if (m_SharedFile.Open (m_Filename, (HANDLE) m_file.m_hFile,
			   PAGE_READONLY,
			   FindFileData.nFileSizeHigh,
			   FindFileData.nFileSizeLow, 0,
			   FILE_MAP_READ) == FALSE)
      {
	  m_file.Close ();
	  m_Display = "Can't open file.";
	  UpdateData (FALSE);
	  return;
      }

    // get header information

    m_fileptr = (char *) (BYTE *) m_SharedFile;

    char *currptr = m_fileptr;

    strncpy (m_header.signature, m_fileptr, 4);
    currptr += 4;

    if (strncmp (m_header.signature, "BIGF", 4) != 0)
      {

	  m_SharedFile.Close ();
	  m_file.Close ();

	  m_Display = "Bad Format";
	  UpdateData (FALSE);
	  return;
      };

    m_header.total_size = le (currptr);
    currptr += 4;
    m_header.num_files = le (currptr);
    currptr += 4;
    m_header.divider = le (currptr);
    currptr += 4;

    m_entries = new TFileEntry[m_header.num_files];

    LVITEM lvItem;
    lvItem.mask = LVIF_TEXT;
    lvItem.iSubItem = 0;

    int i;
    for (i = 0; i < m_header.num_files; i++)
      {
	  m_entries[i].position = le (currptr);
	  currptr += 4;
	  m_entries[i].length = le (currptr);
	  currptr += 4;
	  m_entries[i].filename = currptr;
	  currptr += strlen (m_entries[i].filename) + 1;

	  lvItem.iItem = i;
	  lvItem.pszText = m_entries[i].filename;
	  m_FileList.InsertItem (&lvItem);

	  CString buf;
	  buf.Format ("%d", m_entries[i].length);
	  m_FileList.SetItemText (i, 1, buf);
      }

    m_Display.Format ("Files: %i", m_header.num_files);
    m_Extract.EnableWindow ();
    m_SelectAll.EnableWindow ();
    m_SelectNone.EnableWindow ();
    m_Close.EnableWindow ();
    UpdateData (FALSE);

    m_FileIsValid = TRUE;
}

void
CSLExtractorDlg::OnFileClose ()
{
    if (m_FileIsValid)
      {
	  m_SharedFile.Close ();
	  m_file.Close ();
	  delete[]m_entries;
	  m_FileIsValid = FALSE;
	  m_FileList.DeleteAllItems ();
	  m_Display = "";
      }

    m_SelectAll.EnableWindow (m_FileIsValid);
    m_SelectNone.EnableWindow (m_FileIsValid);
    m_Extract.EnableWindow (m_FileIsValid);
    m_Close.EnableWindow (m_FileIsValid);
    UpdateData (FALSE);

}

void
CSLExtractorDlg::OnClose ()
{
    // TODO: Add your message handler code here and/or call default
    OnFileClose ();
    CDialog::OnClose ();
}

void
CSLExtractorDlg::OnChangeFile ()
{
    UpdateData ();
}


void
CSLExtractorDlg::OnExtract ()
{
    ASSERT (m_FileIsValid);

    // get file list, done automatically
    //UpdateData();  


    POSITION pos = m_FileList.GetFirstSelectedItemPosition ();
    if (pos == NULL)
      {
	  m_Display = "No items were selected!";
	  UpdateData (FALSE);
      }
    else
      {
	  int Error = 0;
	  CString outpath, outparent = m_OutputDir;
	  outparent.TrimRight ('\\');

	  while (pos)
	    {
		int nItem = m_FileList.GetNextSelectedItem (pos);
		// extract file here....
		CStdioFile output;
		outpath = outparent;
		outpath += "\\";
		outpath += m_entries[nItem].filename;
		if (output.
		    Open (outpath,
			  CFile::modeCreate | CFile::modeWrite | CFile::
			  shareDenyWrite | CFile::typeBinary) == 0)
		  {
		      m_Display.Format ("Can't write %s", outpath);
		      UpdateData (FALSE);
		      Error++;
		      continue;
		  }

		m_Display.Format ("Extracting %s", m_entries[nItem].filename);
		UpdateData (FALSE);

		char *currptr = m_fileptr + m_entries[nItem].position;
		CWaitCursor wait;
		output.Write (currptr, m_entries[nItem].length);
	    }

	  if (Error > 0)
	    {
		CString buf;
		buf.Format ("\n%i Errors", Error);
		m_Display += buf;
	    }
	  else
	      m_Display = "Extraction Done!";

	  UpdateData (FALSE);


      }
}

void
CSLExtractorDlg::OnBrowseOutput ()
{

    CoInitialize (NULL);
    BROWSEINFO bi;
    ZeroMemory (&bi, sizeof (bi));

    TCHAR szDisplayName[MAX_PATH];
    szDisplayName[0] = '\0';

    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_DONTGOBELOWDOMAIN;
    bi.pszDisplayName = szDisplayName;
    bi.lpszTitle = TEXT ("Browsing");


    LPITEMIDLIST pidl = SHBrowseForFolder (&bi);

    if (NULL != pidl)
      {
	  SHGetPathFromIDList (pidl, szDisplayName);
	  m_OutputDir = szDisplayName;
	  UpdateData (FALSE);
      }

    LPMALLOC pMalloc;
    SHGetMalloc (&pMalloc);
    pMalloc->Free (pidl);

    CoUninitialize ();
    return;
}

void
CSLExtractorDlg::OnChangeOutputDir ()
{
    UpdateData ();
}

void
CSLExtractorDlg::OnAbout ()
{
    CAboutDlg dlgAbout;
    dlgAbout.DoModal ();

}

BOOL
CAboutDlg::OnInitDialog ()
{
    CDialog::OnInitDialog ();

    m_DisplayAbout =
	"DraconPern - draconpern@hotmail.com\x0D\x0AKingLord - kinglord@sephiroth.com";

    UpdateData (FALSE);
    return TRUE;		// return TRUE unless you set the focus to a control
    // EXCEPTION: OCX Property Pages should return FALSE
}
