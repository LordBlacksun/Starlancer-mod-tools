
#if !defined(AFX_BIGF_H__9E58C63E_C6AB_419D_B12A_44942797CF79__INCLUDED_)
#define AFX_BIGF_H__9E58C63E_C6AB_419D_B12A_44942797CF79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct
{
    char signature[4];		//BIGF
    int total_size;
    int num_files;
    int divider;		// could be end of header or start of 1st file.
}
THeader;

typedef struct
{
    int position, length;
    char *filename;
}
TFileEntry;

int le (char *a);

#endif // !defined(AFX_BIGF_H__9E58C63E_C6AB_419D_B12A_44942797CF79__INCLUDED_)
